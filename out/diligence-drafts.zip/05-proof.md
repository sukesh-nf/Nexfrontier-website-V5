# Proof & Foundation Customers

## CURRENT POSITION

### The thesis matters only if the evidence progresses.

NexFrontier deliberately distinguishes:

ASSUMPTION → HYPOTHESIS → EVIDENCE → CUSTOMER VALIDATION → PAID VALIDATION → REPEATABLE PROOF

These states are not interchangeable.

A compelling thesis is not customer validation.
Customer interest is not paid validation.
One successful outcome is not repeatable proof.

NexFrontier is currently a:

**PROOF-STAGE COMPANY**

The company has developed its thesis, accumulated external market evidence, defined the product direction, built the Foundation Customer pathway and is progressing toward real-enterprise validation.

---

## WHAT CAN BE SUPPORTED TODAY

### THESIS

A coherent proposition exists around:

- AI-mediated market change
- market-enterprise alignment
- economic consequence
- the need for Enterprise Navigational Intelligence

**EXTERNAL EVIDENCE**
There is external evidence that AI is changing important customer, competitive, platform and enterprise behaviours.

This supports investigation of the thesis.

It does not prove NexFrontier's customer economics.

**PRODUCT BUILD**
NexFrontier is building the MVP/Beta required to test its hypotheses in real operating conditions.

**PROOF ARCHITECTURE**
NexFrontier has defined a progression from market evidence through Foundation Customer validation, paid validation and repeatable proof.

**FOUNDER COMMITMENT**
NexFrontier has been founder-funded to date.

That demonstrates founder commitment.

It does not substitute for customer validation.

---

## WHAT NEXFRONTIER DOES NOT YET CLAIM

### NexFrontier does not yet claim:

- Product-Market Fit
- repeatable customer demand
- validated customer economics
- paid validation
- repeatable value realisation
- validated category leadership
- scalable commercial repeatability

Those claims must be earned through evidence.

---

## THE FOUNDATION CUSTOMER ROLE

### Foundation Customers are the next major proof environment.

They are not being positioned as test subjects.

And the proposition is not that they exist simply to help NexFrontier build software.

The intended relationship is reciprocal.

Foundation Customers gain early access to emerging intelligence intended to help leadership understand how effectively the enterprise is keeping pace with a changing market and where economically meaningful opportunity may exist.

NexFrontier gains the operating evidence required to determine whether its thesis is true.

Foundation Customer work is intended to establish:

- whether the problem exists materially inside the enterprise
- whether NexFrontier can observe the relevant enterprise reality
- whether changing market context can be meaningfully connected to it
- whether leadership finds the resulting intelligence useful
- whether a material Value Gap can be identified
- whether that gap can be translated economically
- what action follows

---

## THE FOUR PROOF QUESTIONS

| PRODUCT | CUSTOMER |
|---------|----------|
| Can NexFrontier work in real enterprise conditions? | Does the problem matter enough for leadership to act? |

| ECONOMICS | COMMERCIAL |
|-----------|------------|
| Can NexFrontier identify and help create measurable economic value? | Will customers pay, and can that value repeat? |

---

## THE PROOF PATHWAY

**TODAY: EVIDENCE** → **NEXT: CUSTOMER VALIDATION** → **THEN: PAID VALIDATION** → **THEN: REPEATABLE PROOF**

The evidence required at each stage becomes progressively stronger.

---

## WHY THE DISTINCTIONS MATTER

### One successful enterprise does not establish repeatability.

Leadership enthusiasm does not establish willingness to pay.
Identified economic exposure does not establish realised value.
Realised value does not automatically establish attribution.
A paid customer does not automatically establish repeatable economics.

This is why NexFrontier separates each proof threshold.

---

## NEXT PROOF THRESHOLD

### The immediate threshold is: CUSTOMER VALIDATION

The objective is to obtain enough evidence in real enterprise conditions to support, modify or reject the core product, customer and economic hypotheses.

The threshold after that is:

**PAID VALIDATION**

At that point willingness to pay becomes evidence rather than assumption.

Only then does the question of repeatability become meaningful.

---

### Capital should buy proof, not activity.

---

**Related:** [See What the Next Capital Is Intended to Prove →](/investor-data-room/round)
