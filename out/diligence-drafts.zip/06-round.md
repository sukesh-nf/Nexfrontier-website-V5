# Round & Use of Funds

## CURRENT POSITION

### Fund the proof. Earn the right to scale.

NexFrontier has been founder-funded to date.

External capital should not principally be used to scale an unproven company.

The next capital should principally be used to reduce the uncertainties that determine whether NexFrontier deserves to scale.

The governing principle is:

**Proof first. Scale second.**

---

## WHAT THE CAPITAL IS INTENDED TO PROVE

| PRODUCT PROOF | CUSTOMER PROOF |
|---------------|----------------|
| Demonstrate that Enterprise Navigational Intelligence can operate in real enterprise conditions and generate useful leadership intelligence. | Demonstrate that the problem is sufficiently material that enterprise leadership acts on it. |

| ECONOMIC PROOF | COMMERCIAL PROOF |
|----------------|------------------|
| Demonstrate that market-enterprise misalignment can be translated into measurable economic consequence. | Demonstrate customer willingness to pay and establish the beginnings of repeatable economics. |

Capital should progressively reduce these uncertainties.

---

## WORKING YEAR 1 CAPITAL REQUIREMENT

The current operating plan assumes approximately NZD 1.0M for the first year of the proof-stage plan.

**WORKING OPERATING REQUIREMENT**
This is not final round size, final valuation, final financing structure, or a commitment to particular investment terms.

Those remain subject to the final financing plan.

---

## WHAT THE CAPITAL SUPPORTS

### PRODUCT & ENGINEERING

Build and operate the MVP/Beta capability required to test Enterprise Navigational Intelligence in real enterprise environments.

**FOUNDATION CUSTOMER DELIVERY**
Support the integration, implementation and evidence work required to run the Foundation Customer pathway properly.

**ECONOMIC VALIDATION**
Develop and validate the economic translation required to connect market-enterprise alignment to measurable enterprise value.

**LEAN GO-TO-MARKET**
Secure and support Foundation Customers and progression toward paid validation without prematurely constructing a scaled sales organisation.

**CORE TEAM & OPERATIONS**
Fund the minimum capability required to execute the proof plan while preserving founder focus on product, customers, evidence and capital.

**SECURITY, LEGAL & IP**
Fund the legal, intellectual-property, security and production requirements appropriate to an enterprise intelligence company.

**CONTINGENCY**
Maintain appropriate operating resilience during the proof phase.

---

## WHAT THE NEXT CAPITAL SHOULD BUY

### At the end of the proof phase, investors should expect NexFrontier to have materially better answers to six questions.

**01** — Does the product work?
**02** — Does leadership care?
**03** — Is the economic consequence material?
**04** — Can the value be measured credibly?
**05** — Will customers pay?
**06** — Does the result begin to repeat?

If the capital cannot materially improve those answers, it has not been allocated to the highest-value uncertainty.

---

## CAPITAL AND PROOF PROGRESSION

MVP → FOUNDATION CUSTOMER VALIDATION → PAID BETA → REPEATABILITY EVIDENCE → SCALABLE MARGIN PROOF

Each stage should justify the next level of capital.

Do not imply NexFrontier has already reached later stages.

---

## FOUNDER FUNDING

### Founder funding matters because:

the founding team has carried the thesis and company to the current proof stage before asking external investors to fund the next step.

It is evidence of commitment.

It is not evidence of customer demand.

The investment case must ultimately stand on:

- market evidence
- customer evidence
- economic evidence
- commercial evidence

---

## WHAT POSITIVE PROOF CHANGES

**FROM**
- an emerging enterprise thesis
- a hypothesised economic opportunity
- a proof-stage company

**TOWARD**
- a validated enterprise requirement
- evidenced customer economic value
- a company with a credible basis to scale a potentially new enterprise category

This progression represents the principal value inflection the next capital is intended to create.

---

## WHAT NEGATIVE PROOF CHANGES

### Disciplined proof must also be capable of showing that part of the thesis is wrong.

If customer, economic or commercial evidence does not support the thesis, NexFrontier should learn that before committing substantially more capital to scale.

The purpose of proof is not to validate the founders.

It is to determine what is true.

That is part of the capital discipline.

---

### The current opportunity is to invest before the proof becomes obvious.

And to use the next capital to determine whether it should.

---

**Related:** [Discuss the Investment Case](/market-enquiry?source=investor_data_room) | [Return to Investment Case →](/investor-data-room/investment-case)
